<?php header('Content-type: text/xml; charset=UTF-8'); ?>
<?php echo '<?xml version="1.0" encoding="UTF-8"?>' ?>
<?php echo $content_for_layout ?>