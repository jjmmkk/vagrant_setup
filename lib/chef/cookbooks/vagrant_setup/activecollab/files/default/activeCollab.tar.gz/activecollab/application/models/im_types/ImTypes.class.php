<?php

  /**
  * ImTypes, generated on Wed, 22 Mar 2006 15:35:34 +0100 by 
  * DataObject generation tool
  *
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  class ImTypes extends BaseImTypes {
  
  } // ImTypes 

?>