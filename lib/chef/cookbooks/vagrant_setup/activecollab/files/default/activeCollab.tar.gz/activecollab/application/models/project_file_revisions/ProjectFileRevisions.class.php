<?php

  /**
  * ProjectFileRevisions, generated on Tue, 04 Jul 2006 06:46:08 +0200 by 
  * DataObject generation tool
  *
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  class ProjectFileRevisions extends BaseProjectFileRevisions {
  
  } // ProjectFileRevisions 

?>