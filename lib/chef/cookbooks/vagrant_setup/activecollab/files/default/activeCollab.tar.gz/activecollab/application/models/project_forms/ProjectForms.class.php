<?php

  /**
  * ProjectForms, generated on Wed, 07 Jun 2006 10:14:23 +0200 by 
  * DataObject generation tool
  *
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  class ProjectForms extends BaseProjectForms {
  
  } // ProjectForms 

?>