<?php

  /**
  * ProjectTaskLists, generated on Wed, 08 Mar 2006 15:51:26 +0100 by 
  * DataObject generation tool
  *
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  class ProjectTaskLists extends BaseProjectTaskLists {
  
  } // ProjectTaskLists 

?>