<?php

  /**
  * ProjectTasks, generated on Sat, 04 Mar 2006 12:50:11 +0100 by 
  * DataObject generation tool
  *
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  class ProjectTasks extends BaseProjectTasks {
  
  } // ProjectTasks 

?>