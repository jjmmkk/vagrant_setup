<?php

  /**
  * ProjectUser class
  * Generated on Wed, 15 Mar 2006 22:57:46 +0100 by DataObject generation tool
  *
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  class ProjectUser extends BaseProjectUser {
  
  } // ProjectUser 

?>