<?php
  set_page_title('Error');
?>
We are sorry, but activeCollab failed to connect to the database. Error report has been sent to the administrator so problem should be resolved soon.