<?php
  set_page_title(lang('error'));
?>
<?php echo lang($error_message) ?>