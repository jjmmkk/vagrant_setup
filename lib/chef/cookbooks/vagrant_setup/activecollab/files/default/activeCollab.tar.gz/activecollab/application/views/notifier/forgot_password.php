<?php echo lang('hi john doe', $user->getDisplayName()) ?>,

<?php echo lang('user password reseted', $new_password) ?>

--
<?php echo ROOT_URL ?>