<?php
  define('DATABASE_LIBRARY_PATH', dirname(__FILE__));
?>