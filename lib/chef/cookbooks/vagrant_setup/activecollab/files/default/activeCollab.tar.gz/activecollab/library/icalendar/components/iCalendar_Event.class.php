<?php

  /**
  * Object that represents single iCalendar event
  *
  * @package iCalendar
  * @author Ilija Studen <ilija.studen@gmail.com>
  */
  final class iCalendar_Event extends iCalendar_Component {
  
    /**
    * Construct the iCalendar_Event
    *
    * @access public
    * @param void
    * @return iCalendar_Event
    */
    function __construct() {
      $this->setName('VEVENT');
      $this->setValidProperties(
        'CLASS', 
        'CREATED', 
        'DESCRIPTION', 
        'DTSTART', 
        'GEO', 
        'LAST-MOD', 
        'LOCATION', 
        'ORGANIZER', 
        'PRIORITY', 
        'DTSTAMP', 
        'SEQ', 
        'STATUS', 
        'SUMMARY', 
        'TRANSP', 
        'UID', 
        'URL', 
        'RECURID', 
        'DTEND', 
        'DURATION', 
        'ATTACH', 
        'ATTENDEE', 
        'CATEGORIES', 
        'COMMENT',
        'CONTACT', 
        'EXDATE', 
        'EXRULE', 
        'RSTATUS', 
        'RELATED', 
        'RESOURCES', 
        'RDATE', 
        'RRULE', 
        'X-PROP'
      ); // setValidProperties
    } // __construct
  
  } // iCalendar_Event

?>