	
	
	
	About
	=====
	
	activeCollab is a free, web based project management and collaboration
	tool. It is released under the terms of the General Public License (see
	license.txt for details).
	
	* visit: http://www.activecollab.com/
           http://forum.activecollab.com/
           http://code.activecollab.com/
           	
	* email: ilija.studen@activecollab.com
	
	System requirements
	===================
	
	activeCollab requires a web server, PHP (5.0 or greater) and MySQL with InnoDB
	support. The recommended web server is Apache.
	
	activeCollab is not PHP4 compatible and it will not run on PHP versions prior
	to PHP5.
	
	Recommended:
	
	PHP 5.1+
	MySQL 4.1+ with InnoDB support
	Apache 2.0+
	
	* PHP    : http://www.php.net/
	* MySQL  : http://www.mysql.com/
	* Apache : http://www.apache.org/
	
	Installation
	============
	
	1. Download activeCollab - http://www.activecollab.com/download/
	2. Unpack and upload to your web server
	3. Direct your browser to the /install directory and follow the installation
	   procedure
	   
	You should be finished in a matter of minutes.
	
	
	(c) 2006 by Ilija Studen
	
	
	
	